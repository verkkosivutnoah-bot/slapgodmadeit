SLAPGOD — GUITAR VAULT LITE
Free live guitar loops, 100 BPM, C minor. All guitar played by SLAPGOD.

Want the full Guitar Vault Vol. 1 (50 loops + one-shots)?
https://slapgodmadeit.vercel.app/packs/guitar-vault-vol-1

Instagram: @slapgodmadeit
